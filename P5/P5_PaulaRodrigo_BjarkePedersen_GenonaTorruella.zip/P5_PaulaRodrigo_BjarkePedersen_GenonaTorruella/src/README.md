The NJ program can be executed by running:
        
            python3 NJ.py input.nwk outputfile.nwk