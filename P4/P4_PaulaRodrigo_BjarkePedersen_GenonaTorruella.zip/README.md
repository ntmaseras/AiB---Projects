The rfdist program can be executed by running:
        python3 rfdist.py path1.new path2.new